%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Please feel free to contact hzhou@stat.wisc.edu 
%%% if you have questions 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Description of the code:
%%% Xsource,Xtarget: Row: sample size, Col: one dimension
%%% We consider Xtarget = Xsource*slope + intercept to correct measurement error.
%%% Max_iter: The number of iterations.
%%% Max_intercept_iter: Iterations for the intercept optimization in each loop
%%% Max_slope_iter: Iterations for the slope optimization in each loop
%%% Objective function value is printed on windows after each step 

%%% A general code for multi-dimension transformation is offered at http://www.stat.wisc.edu/~hzhou/
%%% In this special one-dimension measurement error correction case, the
%%% initial here usually leads to global optimal value. This method is more
%%% robust compared to simple scaling directly using the initial. It also
%%% offers a p-value for the significance of this transformation.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Generate data %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global Xsource Ysource Xtarget Ytarget XA bA XB sigma transXA
Simple_Simulation_1 

%---Set up Max_iter (number of iterations)----------------%
%---For each loop, we iteratively optimize slope and intercept-----%

Max_iter = 3;
Max_intercept_iter = 3;
Max_slope_iter = 6;

%---Set up tuning parameter for Gaussian kernel-%
AllDistance=dist2(Xtarget,Xtarget);
sigma=median(AllDistance(AllDistance~=0));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Optimization %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
slope = std(Xtarget)/std(Xsource);
intercept = mean(Xtarget)-std(Xtarget)/std(Xsource)*mean(Xsource); 

for inside_iter = 1:Max_iter  
    XB = Xtarget;
    if Max_intercept_iter>0
    %---We always use gradient descent to solve this easy problem---%
        transXA = Xsource*slope;
        problem.M = euclideanfactory(1,1);
        problem.cost = @Fintercept;
        problem.egrad = @dFintercept;
        options.maxiter = Max_intercept_iter;
        options.verbosity = 0;
        intercept = conjugategradient(problem,intercept,options);  
    end

    XA = Xsource; bA = intercept;   
    problem.M = euclideanfactory(1,1);
    problem.cost = @F;
    problem.egrad = @dF;
    options.maxiter = Max_slope_iter;
    options.verbosity = 2;
    slope = conjugategradient(problem,slope,options); %It can be replaced by steepestdescent%
end

Xsource = Xsource*slope+ones(size(Xsource,1),1)*intercept;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Hypothesis testing %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Hypothesis_testing

fprintf('Slope is %f; intercept is %f \n',slope,intercept);



