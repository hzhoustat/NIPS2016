%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Please feel free to contact hzhou@stat.wisc.edu 
%%% if you have questions 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Description of the code:
%%% Xsource,Xtarget: row: sample size, col: one dimension
%%% We consider Xtarget = Xsource*WS + bs to correct measurement error.
%%% Max_iter: The iteration times we alternate optimize WS and bs
%%% Max_intercept_iter: Iterations for the intercept bs optimization in each loop
%%% Max_Matrix_iter: Iterations for the slope WS optimization in each loop
%%% Objective function value would be printed on windows after each step
%%% Researchers can see it gradually decreases 

%%% A general code for multi-dimension transformation is offered at http://www.stat.wisc.edu/~hzhou/
%%% In this special one-dimension measurement error correction case, the
%%% initial here usually finds global optimal value. This method is more
%%% robust compared to simple scaling directly using the initial. It also
%%% offers a p-value for the significance of this transformation.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Generate data %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global Xsource Ysource Xtarget Ytarget XA bA XB sigma transXA
Simple_Simulation_1 

%---Set up max_iter-------------------------%
%---In each inside loop, we iteratively optimize slope and intercept-----%

Max_iter = 3;
Max_intercept_iter = 3;
Max_Matrix_iter = 6;

%---Set up tuning parameter for Gaussian kernel, default is median dist-%
% AllDistance=dist2(Xsource,Xtarget);
% sigma=median(AllDistance(AllDistance~=0));
sigma=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Optimization %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
WS = std(Xtarget)/std(Xsource);
bs = mean(Xtarget)-std(Xtarget)/std(Xsource)*mean(Xsource); 

for inside_iter = 1:Max_iter  
    XB = Xtarget;
    if Max_intercept_iter>0
    %---We always use gradient descent to solve this easy problem---%
        transXA = Xsource*WS;
        problem.M = euclideanfactory(1,1);
        problem.cost = @Fintercept;
        problem.egrad = @dFintercept;
        options.maxiter = Max_intercept_iter;
        options.verbosity = 0;
        bs = conjugategradient(problem,bs,options);  
    end

    XA = Xsource; bA = bs;   
    problem.M = euclideanfactory(1,1);
    problem.cost = @F;
    problem.egrad = @dF;
    options.maxiter = Max_Matrix_iter;
    options.verbosity = 2;
    WS = conjugategradient(problem,WS,options); %Can use steepestdescent%
end

Xsource = Xsource*WS+ones(size(Xsource,1),1)*bs;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Hypothesis testing %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Hypothesis_testing

fprintf('Slope is %f; intercept is %f \n',WS,bs);



