function [t] = SGDstepsize(iter)
t = 0.5;
end